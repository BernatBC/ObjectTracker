# Detect > 2023-06-17 11:42am
https://universe.roboflow.com/upc-3sj4d/detect-ajjao

Provided by a Roboflow user
License: CC BY 4.0

